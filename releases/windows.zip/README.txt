Windows:
Nothing to do just run the free_project.exe

MacOS:
Install SDL1.2, SDL_Image1.2, SDL_TTF1.2, SDL_Mixer1.2
Then run the executable

Linux:
sudo apt-get install libsdl1.2-dev libsdl-image1.2-dev libsdl-mixer1.2-dev libsdl-ttf2.0-dev
Then run the executable free_project
